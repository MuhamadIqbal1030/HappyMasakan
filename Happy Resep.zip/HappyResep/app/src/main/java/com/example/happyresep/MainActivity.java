package com.example.happyresep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public DataAdapter dataAdapter;
    public RecyclerView recyclerView;
    public ArrayList<ModelData> modelDataArrayList=new ArrayList<ModelData>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //membuat data yang akan ditampilkan dalam list
        //file .html mengambil di folder assets
        inputData("Ayam Panggang","artikel_1.html");
        inputData("Sate Ayam","artikel_2.html");
        inputData("Pizza Sosis Jumbo","artikel_3.html");
        inputData("Nasi Goreng Spesial","artikel_4.html");
        inputData("Fuyung Hai","artikel_5.html");
        inputData("Lobster bumbu Padang","artikel_6.html");
        inputData("Sop Iga Sapi Spesial","artikel_7.html");
        inputData("Opor Ayam Spesial","artikel_8.html");
        inputData("Bebek Goreng Sambel Ijo","artikel_9.html");
        inputData("Soto Ayam Kampung","artikel_10.html");
        inputData("Bakso Ayam","artikel_11.html");
        inputData("Ikan Gurame Bakar","artikel_12.html");
        inputData("Pisang Bakar Coklat Keju","artikel_13.html");
        inputData("Keto Martabak Terang Bulan","artikel_14.html");
        inputData("Ingkung Ayam Kampung","artikel_15.html");
        //inputData("Artikel 16","artikel_16.html");

        //menampilkan data ke dalam recyclerView
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        dataAdapter = new DataAdapter(this,modelDataArrayList);
        recyclerView.setAdapter(dataAdapter);

        //menambahakan header
        ModelData headerModel = new ModelData();
        headerModel.setViewType(2);
        modelDataArrayList.add(0,headerModel);

        //menambahkan footer
        ModelData footerModel = new ModelData();
        footerModel.setViewType(3);
        modelDataArrayList.add(footerModel);
    }

    //fungsi input
    public void inputData(String judul,String konten){
        ModelData modelData = new ModelData();
        modelData.setJudul(judul);
        modelData.setKonten(konten);
        modelData.setViewType(1);
        modelDataArrayList.add(modelData);
    }

}

